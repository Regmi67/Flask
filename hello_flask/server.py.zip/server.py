from flask import Flask

app = Flask(__name__)   
@app.route('/')          
def hello_world():
    return 'Hello World I am the webPage!' 

@app.route('/dojo')
def hello_dojo():
    print(" Dojo")
    return " Dojo"

@app.route('/flask')
def say_flask():
    return "Hi Flask!"

@app.route('/say/<name>')
def say_name(name):
    return f"Hi {name.capitalize()}!"

# @app.route( '/john')
# def say_john():
#     return "Hi John!"

@app.route('/repeat/<int:num>/<string:word>')
def repeat_word(num, word):
    output = ''

    for i in range(0,num):
        output += f"<p>{word}</p>"

    return output

if __name__=="__main__":    
    app.run(debug=True,port=5000)    
